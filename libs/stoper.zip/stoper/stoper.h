/* 
Simple stopwatch library for the Arduino.
Piotr Slezak
*/
 
#ifndef Stoper_h
#define Stoper_h
 
#if ARDUINO >= 100
    #include "Arduino.h"
#else
    #include "WProgram.h"
#endif
 
class Stoper 
{
public:
	/* Stoper
	inSensorPin - numer pinu do którego podłączona będzie fotokomórka
	inResetPin - numer pinu do którego podłączony będzie przycisk resetu
	inDelay_ms - czas w [ms] poniżej którego nie będzie możliwe zatrzymanie odliczania po przerwaniu fotokomórki
	*/
	Stoper(unsigned int inSensorPin, unsigned int inResetPin, unsigned long inDelay_ms);
		
	void Update(); /* główna pętla funkcji */
	bool Working(); /* zmienna logiczna określająca, czy stoper aktualnie odmierza czas */
	bool Finish(); /* odliczanie zostało zakończone */
	
	unsigned long Czas();
	unsigned int Czas_milsekund();
	unsigned int Czas_led_milsekund();
	unsigned int Czas_sekund();
	unsigned int Cas_minut();
	
private:

    int SensorState;
    int ResetState;
    bool odliczanie;
    bool wymaganyReset;
	bool koniecLiczenia;
    
    unsigned long interval = 1;
    unsigned long czasStartu;
    unsigned long czasStopu;
};
#endif
