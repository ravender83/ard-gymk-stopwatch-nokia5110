/* 
Simple stopwatch library for the Arduino.
Piotr Slezak
*/

#include "stoper.h"

 Stoper::Stoper(int inSensorPin, int inResetPin, long inDelay_ms) {
      pinMode(inSensorPin, INPUT_PULLUP);
      pinMode(inResetPin, INPUT_PULLUP);

      SensorState = LOW;
      ResetState = LOW;
      odliczanie = LOW;
      wymaganyReset = LOW;
	  koniecLiczenia = LOW;

      czasStartu = 0;
      czasStopu = 0;
    }
	
	void  Stoper::Update() {
      SensorState = digitalRead(inSensorPin);
      ResetState = digitalRead(inResetPin);

      if ((odliczanie == LOW) && (SensorState == LOW) && (ResetState == HIGH) &&(wymaganyReset == LOW)) {
        czasStopu = 0;
        czasStartu = millis() / interval;
        odliczanie = HIGH;
        wymaganyReset = HIGH;
      }

      if ((odliczanie == HIGH) && (SensorState == LOW) && (ResetState == HIGH) && (millis() / interval - czasStartu)>inDelay_ms) {
        czasStopu = millis() / interval;
        odliczanie = LOW;
		koniecLiczenia = HIGH;
      }

      if ((SensorState == HIGH) && (ResetState == LOW)) {
        czasStopu = 0;
        czasStartu = 0;
        odliczanie = LOW;
        wymaganyReset = LOW;
		koniecLiczenia = LOW;
      }
    }

    bool  Stoper::Working() {return odliczanie;}

	bool  Stoper::Finish() {return koniecLiczenia;}

    unsigned long  Stoper::Czas() {
      if (odliczanie == HIGH) return (millis() / interval - czasStartu);
      else return (czasStopu - czasStartu);}
	
	unsigned int Stoper::Czas_milsekund(); {return Czas() % 1000;}
		
	unsigned int Stoper::Czas_led_milsekund(); {return (Czas() / 10) % 100;}
		
	unsigned int Stoper::Czas_sekund(); {return (Czas() / 1000) % 60;}
		
	unsigned int Stoper::Cas_minut(); {return (Czas() / 60000) % 60;}